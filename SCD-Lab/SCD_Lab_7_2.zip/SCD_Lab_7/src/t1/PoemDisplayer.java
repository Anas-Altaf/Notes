package t1;

import javax.swing.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class PoemDisplayer extends JFrame {

    JTable jTable;
    JScrollPane jScrollPane;
    Object[][] tableData;
    String[] columnNames = {"Title", "Misra 1", "Misra 2"};

    public PoemDisplayer() {

        this.setTitle("Poem Display");

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public static void main(String[] args) throws IOException {
        String filePath = "src/t1/TextFiles/Poem.txt";
        PoemDisplayer poemDisplayer = new PoemDisplayer();
        poemDisplayer.fileDataExtractor(filePath);
        poemDisplayer.displayData();

    }

    public void fileDataExtractor(String filePath) throws IOException {
        File poemFile = new File(filePath);
        FileReader fileReader = new FileReader(poemFile);
        BufferedReader bufferedReader = new BufferedReader(fileReader);
        String singleLine;
        String currentTitle = null;
        List<List<String>> data = new ArrayList<>();
        boolean skipSection = false;
        while ((singleLine = bufferedReader.readLine()) != null) {

            if (singleLine.contains("_________")) {
                skipSection = true;
                continue;
            }

            if (singleLine.contains("==========")) {
                skipSection = false;
                continue;
            }

            if (skipSection) {
                continue;
            }
            if (singleLine.contains("[") && singleLine.contains("]")) {
                currentTitle = singleLine.substring(singleLine.indexOf('[') + 1, singleLine.indexOf(']')).trim();
            }


            while (singleLine.contains("(") && singleLine.contains(")")) {

                String misraLine = singleLine.substring(singleLine.indexOf('(') + 1, singleLine.indexOf(')')).trim();
                singleLine = singleLine.substring(singleLine.indexOf(')') + 1);


                String[] misras = misraLine.split(" ... ");


                if (misras.length == 2) {
                    List<String> row = new ArrayList<>();
                    row.add(currentTitle);
                    row.add(misras[0].trim());
                    row.add(misras[1].trim());
                    data.add(row);
                }
            }
        }

        bufferedReader.close();
        tableData = new Object[data.size()][3];

        for (int i = 0; i < data.size(); i++) {
            List<String> row = data.get(i);
            for (int j = 0; j < row.size(); j++) {
                tableData[i][j] = row.get(j);
            }
        }

        jTable = new JTable(tableData, columnNames);
    }

    public void displayData() {

        jTable.setBounds(30, 40, 200, 300);
        jScrollPane = new JScrollPane(jTable);
        this.add(jScrollPane);
        this.setSize(500, 500);
        this.setVisible(true);
    }

}


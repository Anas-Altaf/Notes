package t1_LayeredArch.pl;

import t1_LayeredArch.bll.EmployeeBLL;
import t1_LayeredArch.dto.EmployeeDTO;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import java.awt.*;
import java.util.List;

public class EmployeeManagementView extends JFrame {
    private JTable employeeTable;
    private DefaultTableModel tableModel;
    private JTextField idField, nameField, salaryField;
    private JComboBox<String> departmentBox, filterBox;
    private EmployeeBLL bll;

    public EmployeeManagementView(EmployeeBLL bll) {
        this.bll = bll;
        setTitle("Employee Management System");


        String[] columnNames = {"ID", "Name", "Department", "Salary"};
        tableModel = new DefaultTableModel(columnNames, 0);
        employeeTable = new JTable(tableModel) {
            @Override
            public Component prepareRenderer(TableCellRenderer renderer, int row, int column) {
                Component c = super.prepareRenderer(renderer, row, column);
                double salary = (double) getValueAt(row, 3);
                if (salary > 100000) {
                    c.setBackground(Color.PINK);
                } else if (salary > 50000) {
                    c.setBackground(Color.GREEN);
                } else {
                    c.setBackground(Color.WHITE);
                }
                return c;
            }
        };

        JScrollPane scrollPane = new JScrollPane(employeeTable);


        JPanel inputPanel = new JPanel(new GridLayout(4, 2));
        idField = new JTextField();
        nameField = new JTextField();
        salaryField = new JTextField();
        departmentBox = new JComboBox<>(new String[]{"IT", "HR", "Sales", "SE"});
        filterBox = new JComboBox<>(new String[]{"All", "IT", "HR", "Sales", "SE"});

        inputPanel.add(new JLabel("ID:"));
        inputPanel.add(idField);
        inputPanel.add(new JLabel("Name:"));
        inputPanel.add(nameField);
        inputPanel.add(new JLabel("Department:"));
        inputPanel.add(departmentBox);
        inputPanel.add(new JLabel("Salary:"));
        inputPanel.add(salaryField);


        JButton addButton = new JButton("Add Employee");
        JButton updateButton = new JButton("Update Employee");
        JButton deleteButton = new JButton("Delete Employee");
        JButton sortSalaryButton = new JButton("Sort by Salary");

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(addButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(sortSalaryButton);
        buttonPanel.add(new JLabel("Filter by Department:"));
        buttonPanel.add(filterBox);


        setLayout(new BorderLayout());
        add(scrollPane, BorderLayout.CENTER);
        add(inputPanel, BorderLayout.SOUTH);
        add(buttonPanel, BorderLayout.NORTH);


        loadTableData(bll.getAllEmployees());


        addButton.addActionListener(e -> addEmployee());
        updateButton.addActionListener(e -> updateEmployee());
        deleteButton.addActionListener(e -> deleteEmployee());
        sortSalaryButton.addActionListener(e -> sortBySalary());
        filterBox.addActionListener(e -> filterByDepartment());

        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    private void loadTableData(List<EmployeeDTO> employees) {
        tableModel.setRowCount(0);
        for (EmployeeDTO emp : employees) {
            tableModel.addRow(new Object[]{emp.getId(), emp.getName(), emp.getDepartment(), emp.getSalary()});
        }
    }

    private void addEmployee() {
        String id = idField.getText();
        String name = nameField.getText();
        String department = (String) departmentBox.getSelectedItem();
        double salary = Double.parseDouble(salaryField.getText());

        EmployeeDTO employee = new EmployeeDTO(id, name, department, salary);
        bll.addEmployee(employee);
        loadTableData(bll.getAllEmployees());
    }

    private void updateEmployee() {
        int selectedRow = employeeTable.getSelectedRow();
        if (selectedRow >= 0) {
            String id = (String) tableModel.getValueAt(selectedRow, 0);
            String name = nameField.getText();
            String department = (String) departmentBox.getSelectedItem();
            double salary = Double.parseDouble(salaryField.getText());

            EmployeeDTO updatedEmployee = new EmployeeDTO(id, name, department, salary);
            bll.updateEmployee(id, updatedEmployee);
            loadTableData(bll.getAllEmployees());
        }
    }

    private void deleteEmployee() {
        int selectedRow = employeeTable.getSelectedRow();
        if (selectedRow >= 0) {
            String id = (String) tableModel.getValueAt(selectedRow, 0);
            bll.deleteEmployee(id);
            loadTableData(bll.getAllEmployees());
        }
    }

    private void sortBySalary() {
        loadTableData(bll.sortEmployeesBySalary());
    }

    private void filterByDepartment() {
        String selectedDepartment = (String) filterBox.getSelectedItem();
        loadTableData(bll.filterByDepartment(selectedDepartment));
    }
}

package t1_LayeredArch.dal;

import t1_LayeredArch.dto.EmployeeDTO;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class EmployeeDAL {
    private final String filePath = "src/t1_LayeredArch/dal/employees.txt";

    public List<EmployeeDTO> getAllEmployees() {
        List<EmployeeDTO> employees = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");
                EmployeeDTO emp = new EmployeeDTO(data[0], data[1], data[2], Double.parseDouble(data[3]));
                employees.add(emp);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return employees;
    }

    public void saveEmployees(List<EmployeeDTO> employees) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(filePath))) {
            for (EmployeeDTO emp : employees) {
                bw.write(emp.getId() + "," + emp.getName() + "," + emp.getDepartment() + "," + emp.getSalary());
                bw.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

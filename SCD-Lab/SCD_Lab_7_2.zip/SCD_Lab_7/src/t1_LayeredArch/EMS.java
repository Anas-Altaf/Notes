package t1_LayeredArch;

import t1_LayeredArch.bll.EmployeeBLL;
import t1_LayeredArch.pl.EmployeeManagementView;

public class EMS {
    public static void main(String[] args) {
        EmployeeBLL bll = new EmployeeBLL();
        new EmployeeManagementView(bll);
    }
}

package t1_LayeredArch.bll;

import t1_LayeredArch.dal.EmployeeDAL;
import t1_LayeredArch.dto.EmployeeDTO;

import java.util.List;
import java.util.stream.Collectors;

public class EmployeeBLL {
    private final EmployeeDAL dal;
    private List<EmployeeDTO> employees;

    public EmployeeBLL() {
        dal = new EmployeeDAL();
        employees = dal.getAllEmployees();
    }

    public List<EmployeeDTO> getAllEmployees() {
        return employees;
    }

    public void addEmployee(EmployeeDTO employee) {
        employees.add(employee);
        dal.saveEmployees(employees);
    }

    public void updateEmployee(String id, EmployeeDTO updatedEmployee) {
        for (EmployeeDTO emp : employees) {
            if (emp.getId().equals(id)) {
                emp.setName(updatedEmployee.getName());
                emp.setDepartment(updatedEmployee.getDepartment());
                emp.setSalary(updatedEmployee.getSalary());
                break;
            }
        }
        dal.saveEmployees(employees);
    }

    public void deleteEmployee(String id) {
        employees.removeIf(emp -> emp.getId().equals(id));
        dal.saveEmployees(employees);
    }

    public List<EmployeeDTO> filterByDepartment(String department) {
        return employees.stream()
                .filter(emp -> department.equals("All") || emp.getDepartment().equals(department))
                .collect(Collectors.toList());
    }

    public List<EmployeeDTO> sortEmployeesBySalary() {
        return employees.stream()
                .sorted((e1, e2) -> Double.compare(e2.getSalary(), e1.getSalary()))
                .collect(Collectors.toList());
    }
}
